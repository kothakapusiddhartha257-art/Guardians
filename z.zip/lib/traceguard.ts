export type Verdict = 'MALICIOUS' | 'SUSPICIOUS' | 'CLEAN'
export type Severity = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW'
export type FeedAction = 'QUARANTINED' | 'FLAGGED' | 'DELIVERED'

export interface Scores {
  threat: number
  infrastructure: number
  attribution: number
}

export interface Hop {
  host: string
  ip?: string
  label: string
  trusted: boolean
  frontier?: boolean
}

export interface AuthResult {
  protocol: 'SPF' | 'DKIM' | 'DMARC' | 'ARC'
  result: 'PASS' | 'FAIL' | 'REJECT' | 'NONE' | 'SOFTFAIL'
  detail: string
}

export interface Investigation {
  id: string
  subject: string
  from: { name: string; address: string }
  replyTo?: string
  messageId: string
  sha256: string
  receivedAt: string
  verdict: Verdict
  scores: Scores
  signals: string[]
  auth: AuthResult[]
  hops: Hop[]
  origin: { ip: string; city: string; country: string; asn: string; confidence: number; humanActor: string }
  route: { name: string; coords: [number, number] }[]
  domains: { observed: string; impersonates: string; ageDays: number; risk: number; technique: string }
  urls: { displayed: string; actual: string; redirects: string[]; classification: string }[]
  attachments: { name: string; claimed: string; detected: string; magic: string; entropy: number; sha256: string }[]
  content: { text: string; phrases: { phrase: string; intent: string }[] }
  campaign: { id: string; name: string; previousCases: number; sharedDomains: number; sharedHashes: number }
  custody: { event: string; timestamp: string; actor: string; prevHash: string; hash: string }[]
}

export const INVESTIGATION: Investigation = {
  id: 'TG-2026-0482',
  subject: 'URGENT: Wire Transfer Required Before 5 PM',
  from: { name: 'CEO', address: 'ceo@company-secure.com' },
  replyTo: 'payment@company-support.co',
  messageId: '8f19a@company-secure.com',
  sha256: '8a9d8c1e4b27f0a3d6e19c5b7f2a8d41c3e6b9f0a2d5c8e1b4f7a0d3c6e9f47c',
  receivedAt: '2026-09-02T14:12:08Z',
  verdict: 'MALICIOUS',
  scores: { threat: 94, infrastructure: 83, attribution: 40 },
  signals: ['DMARC FAIL', 'REPLY-TO MISMATCH', 'FINANCIAL DIRECTIVE', 'YOUNG DOMAIN', 'IP LITERAL URL'],
  auth: [
    { protocol: 'SPF', result: 'FAIL', detail: '185.23.11.4 is not authorized by company-secure.com (v=spf1 include:_spf.google.com -all)' },
    { protocol: 'DKIM', result: 'FAIL', detail: 'Signature body hash mismatch. Selector s1._domainkey.company-secure.com not found.' },
    { protocol: 'DMARC', result: 'FAIL', detail: 'Policy p=reject. Neither SPF nor DKIM aligned with From: domain.' },
    { protocol: 'ARC', result: 'PASS', detail: 'ARC-Seal i=1 by smtp-relay.net (cv=none). Relay sealed an already-failing chain.' },
  ],
  hops: [
    { host: 'mx.recipient-gateway.com', label: 'Recipient Gateway', trusted: true },
    { host: 'outlook.office365.com', ip: '40.107.22.11', label: 'Microsoft 365', trusted: true },
    { host: 'smtp-relay.net', ip: '203.0.113.8', label: 'External Relay', trusted: true, frontier: true },
    { host: 'mail.company-secure.com', ip: '185.23.11.4', label: 'Origin Server', trusted: false },
    { host: 'UNKNOWN', label: 'Unknown Origin', trusted: false },
  ],
  origin: { ip: '185.23.11.4', city: 'Frankfurt', country: 'Germany', asn: 'AS208091 Xhost Internet Solutions', confidence: 83, humanActor: 'Unknown / Proxied' },
  route: [
    { name: 'Mumbai, IN', coords: [72.87, 19.07] },
    { name: 'Singapore, SG', coords: [103.82, 1.35] },
    { name: 'Frankfurt, DE', coords: [8.68, 50.11] },
    { name: 'Amsterdam, NL', coords: [4.9, 52.37] },
  ],
  domains: { observed: 'company-secure.com', impersonates: 'company.com', ageDays: 3, risk: 96, technique: 'Descriptive suffix + lookalike' },
  urls: [
    {
      displayed: 'https://login.microsoft.com',
      actual: 'http://185.23.11.4/auth',
      redirects: ['http://185.23.11.4/auth', 'http://185.23.11.4/r?u=0x3f', 'http://185.23.11.4/o365/login.php'],
      classification: 'Credential harvesting page',
    },
  ],
  attachments: [
    {
      name: 'invoice.pdf',
      claimed: 'PDF Document',
      detected: 'Windows PE Executable',
      magic: '4D 5A 90 00',
      entropy: 7.8,
      sha256: 'c1f2e3d4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2',
    },
  ],
  content: {
    text:
      'I need you to process an URGENT wire transfer immediately for the Henderson acquisition. This is time sensitive and confidential — do not contact anyone else about this until it is complete. I am in meetings all day and can only be reached at this address. Please confirm once the funds have been sent before 5 PM.',
    phrases: [
      { phrase: 'URGENT', intent: 'Urgency pressure' },
      { phrase: 'wire transfer immediately', intent: 'Financial directive' },
      { phrase: 'do not contact anyone', intent: 'Isolation tactic' },
      { phrase: 'can only be reached at this address', intent: 'Channel control' },
      { phrase: 'before 5 PM', intent: 'Deadline coercion' },
    ],
  },
  campaign: { id: 'CAM-2026-08', name: 'Executive Wire Fraud Ring', previousCases: 4, sharedDomains: 8, sharedHashes: 3 },
  custody: [
    { event: 'INGESTED', timestamp: '2026-09-02T14:12:08.114Z', actor: 'gateway@traceguard', prevHash: '0000…0000', hash: '8a9d…f47c' },
    { event: 'PARSED', timestamp: '2026-09-02T14:12:08.302Z', actor: 'parser@traceguard', prevHash: '8a9d…f47c', hash: '3b7e…19a2' },
    { event: 'AUTHENTICATED', timestamp: '2026-09-02T14:12:08.611Z', actor: 'auth-engine@traceguard', prevHash: '3b7e…19a2', hash: 'd41c…7e08' },
    { event: 'ANALYZED', timestamp: '2026-09-02T14:12:09.947Z', actor: 'forensics@traceguard', prevHash: 'd41c…7e08', hash: 'f0a2…c6e9' },
    { event: 'QUARANTINED', timestamp: '2026-09-02T14:12:10.020Z', actor: 'gateway@traceguard', prevHash: 'f0a2…c6e9', hash: '61b4…a0d3' },
    { event: 'CASE CREATED', timestamp: '2026-09-02T14:12:10.188Z', actor: 'analyst.rk@company', prevHash: '61b4…a0d3', hash: '9e2f…5b71' },
  ],
}

export interface FeedItem {
  id: string
  action: FeedAction
  score: number
  subject: string
  from: string
  signals: string[]
  time: string
}

export const FEED_SEED: FeedItem[] = [
  { id: 'TG-2026-0482', action: 'QUARANTINED', score: 94, subject: 'CEO URGENT — Wire Transfer Required', from: 'finance@company-payments.co', signals: ['DMARC FAIL', 'REPLY-TO MISMATCH', 'FINANCIAL DIRECTIVE'], time: '14:12:10' },
  { id: 'TG-2026-0481', action: 'FLAGGED', score: 61, subject: 'Your Office 365 password expires today', from: 'no-reply@micros0ft-security.com', signals: ['LOOKALIKE DOMAIN', 'IP LITERAL URL'], time: '14:11:52' },
  { id: 'TG-2026-0480', action: 'DELIVERED', score: 4, subject: 'Weekly engineering digest', from: 'digest@company.com', signals: ['SPF PASS', 'DKIM PASS'], time: '14:11:31' },
  { id: 'TG-2026-0479', action: 'QUARANTINED', score: 97, subject: 'Invoice #88213 attached', from: 'billing@vendor-invoices.net', signals: ['DISGUISED EXECUTABLE', 'ENTROPY 7.8', 'YOUNG DOMAIN'], time: '14:10:58' },
  { id: 'TG-2026-0478', action: 'DELIVERED', score: 2, subject: 'Re: Q3 roadmap review', from: 'maya@company.com', signals: ['SPF PASS', 'DMARC PASS'], time: '14:10:40' },
]

export const FEED_POOL: Omit<FeedItem, 'id' | 'time'>[] = [
  { action: 'FLAGGED', score: 58, subject: 'DocuSign: Action required on contract', from: 'docs@docusign-notify.co', signals: ['REPLY-TO MISMATCH', 'URL SHORTENER'] },
  { action: 'DELIVERED', score: 6, subject: 'Lunch order confirmation', from: 'orders@cater.com', signals: ['SPF PASS', 'DKIM PASS'] },
  { action: 'QUARANTINED', score: 91, subject: 'Payroll update: verify bank details', from: 'hr@company-hr-portal.com', signals: ['SPF FAIL', 'CREDENTIAL HARVEST', 'DOMAIN 2 DAYS OLD'] },
  { action: 'DELIVERED', score: 3, subject: 'Design review notes', from: 'alex@company.com', signals: ['DMARC PASS'] },
  { action: 'FLAGGED', score: 44, subject: 'Shared file: Budget_FY26.xlsx', from: 'share@onedrive-files.net', signals: ['MACRO DETECTED', 'EXTERNAL RELAY'] },
  { action: 'QUARANTINED', score: 88, subject: 'Final notice: account suspension', from: 'security@paypa1.com', signals: ['HOMOGLYPH', 'DKIM FAIL', 'IP LITERAL URL'] },
]

export interface CaseRow {
  id: string
  severity: Severity
  subject: string
  from: string
  verdict: Verdict
  threat: number
  status: 'OPEN' | 'TRIAGED' | 'CONTAINED' | 'CLOSED'
  analyst: string
  opened: string
  campaign?: string
}

export const CASES: CaseRow[] = [
  { id: 'TG-2026-0482', severity: 'CRITICAL', subject: 'URGENT: Wire Transfer Required Before 5 PM', from: 'ceo@company-secure.com', verdict: 'MALICIOUS', threat: 94, status: 'OPEN', analyst: 'R. Kapoor', opened: '2026-09-02', campaign: 'CAM-2026-08' },
  { id: 'TG-2026-0479', severity: 'CRITICAL', subject: 'Invoice #88213 attached', from: 'billing@vendor-invoices.net', verdict: 'MALICIOUS', threat: 97, status: 'TRIAGED', analyst: 'J. Okafor', opened: '2026-09-02', campaign: 'CAM-2026-11' },
  { id: 'TG-2026-0471', severity: 'HIGH', subject: 'Your Office 365 password expires today', from: 'no-reply@micros0ft-security.com', verdict: 'MALICIOUS', threat: 81, status: 'CONTAINED', analyst: 'R. Kapoor', opened: '2026-09-01', campaign: 'CAM-2026-09' },
  { id: 'TG-2026-0466', severity: 'HIGH', subject: 'Payroll update: verify bank details', from: 'hr@company-hr-portal.com', verdict: 'MALICIOUS', threat: 89, status: 'OPEN', analyst: 'M. Chen', opened: '2026-09-01', campaign: 'CAM-2026-08' },
  { id: 'TG-2026-0458', severity: 'MEDIUM', subject: 'Shared file: Budget_FY26.xlsx', from: 'share@onedrive-files.net', verdict: 'SUSPICIOUS', threat: 52, status: 'TRIAGED', analyst: 'J. Okafor', opened: '2026-08-31' },
  { id: 'TG-2026-0451', severity: 'MEDIUM', subject: 'DocuSign: Action required on contract', from: 'docs@docusign-notify.co', verdict: 'SUSPICIOUS', threat: 47, status: 'CLOSED', analyst: 'M. Chen', opened: '2026-08-30' },
  { id: 'TG-2026-0440', severity: 'LOW', subject: 'Newsletter: September product updates', from: 'news@saasvendor.com', verdict: 'CLEAN', threat: 12, status: 'CLOSED', analyst: 'Auto', opened: '2026-08-29' },
  { id: 'TG-2026-0437', severity: 'HIGH', subject: 'Final notice: account suspension', from: 'security@paypa1.com', verdict: 'MALICIOUS', threat: 86, status: 'CONTAINED', analyst: 'R. Kapoor', opened: '2026-08-29', campaign: 'CAM-2026-09' },
]

export const CASE_COUNTS: Record<Severity, number> = { CRITICAL: 8, HIGH: 23, MEDIUM: 41, LOW: 127 }

export interface Campaign {
  id: string
  name: string
  targets: number
  sharedIps: number
  relatedEmails: number
  confidence: number
  firstSeen: string
  lastSeen: string
  tactic: string
  status: 'ACTIVE' | 'DORMANT' | 'CONTAINED'
}

export const CAMPAIGNS: Campaign[] = [
  { id: 'CAM-2026-08', name: 'Executive Wire Fraud Ring', targets: 8, sharedIps: 4, relatedEmails: 12, confidence: 91, firstSeen: '2026-08-14', lastSeen: '2026-09-02', tactic: 'BEC / Wire fraud', status: 'ACTIVE' },
  { id: 'CAM-2026-09', name: 'Office 365 Credential Harvest', targets: 214, sharedIps: 6, relatedEmails: 63, confidence: 88, firstSeen: '2026-08-02', lastSeen: '2026-09-01', tactic: 'Credential phishing', status: 'ACTIVE' },
  { id: 'CAM-2026-11', name: 'Invoice Loader Distribution', targets: 37, sharedIps: 3, relatedEmails: 19, confidence: 84, firstSeen: '2026-08-27', lastSeen: '2026-09-02', tactic: 'Malware delivery', status: 'ACTIVE' },
  { id: 'CAM-2026-05', name: 'Payroll Redirect Cluster', targets: 12, sharedIps: 2, relatedEmails: 9, confidence: 76, firstSeen: '2026-07-10', lastSeen: '2026-08-11', tactic: 'Payroll diversion', status: 'DORMANT' },
  { id: 'CAM-2026-03', name: 'Homoglyph Payment Portal', targets: 52, sharedIps: 5, relatedEmails: 28, confidence: 79, firstSeen: '2026-06-18', lastSeen: '2026-07-30', tactic: 'Brand impersonation', status: 'CONTAINED' },
]

export const GATEWAY_METRICS = { inbound: 12847, quarantined: 43, flagged: 127, delivered: 12677 }

export function verdictColor(v: Verdict | FeedAction | Severity) {
  switch (v) {
    case 'MALICIOUS':
    case 'QUARANTINED':
    case 'CRITICAL':
      return 'text-critical'
    case 'HIGH':
      return 'text-warning'
    case 'SUSPICIOUS':
    case 'FLAGGED':
    case 'MEDIUM':
      return 'text-suspicious'
    default:
      return 'text-safe'
  }
}

export function scoreColor(score: number) {
  if (score >= 80) return 'text-critical'
  if (score >= 60) return 'text-warning'
  if (score >= 35) return 'text-suspicious'
  return 'text-safe'
}
